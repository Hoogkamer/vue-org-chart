var UINAMES = {
  person: {
    name: 'Name',
    function: 'Function',
    id: 'Employee ID',
    departments: 'Departments'
  },
  sidebar: {
    detailTabName: 'Details',
    peopleTabName: 'People',
    departmentName: 'Name',
    departmentManager: 'Manager',
    departmentDescription: 'Description',
    departmentType: 'Department type',
    departmentHierarchy: 'Hierarchy',
    departmentTypeStaff: 'Staff department',
    departmentTypeNormal: 'Normal department',
    managerOfDepartment: 'Manager of department'
  }
}
